IPTM 5.30.1 OFFLINE TESTS
php tests/test_regressions.php
php tests/test_rules_matrix.php
php tests/test_service_combinations.php
php tests/test_draft_race.php
python3 -B tests/test_optimizer.py
python3 -B tests/test_ssh_qos_5301.py

Nessuna prova qui applica regole al kernel. I test del rules.v4 allegato sono facoltativi e richiedono il file montato in /mnt/data.
